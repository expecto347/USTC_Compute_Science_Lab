#ifndef __TSK_ARR_H__
#define __TSK_ARR_H__

extern int run;
extern int time;
void oneTickUpdateTsk(void);
void arrangeTsk();

#endif