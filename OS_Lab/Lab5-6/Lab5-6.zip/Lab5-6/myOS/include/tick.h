#ifndef __TICK_H__
#define __TICK_H__

void setTickHook(void (*func)(void));

#endif