#ifndef __MEMTESTCASE_H__
#define __MEMTESTCASE_H__

void memTestCaseInit(void);

#endif