gcc Polynomial.c -lm -o Polynomial

./Polynomial